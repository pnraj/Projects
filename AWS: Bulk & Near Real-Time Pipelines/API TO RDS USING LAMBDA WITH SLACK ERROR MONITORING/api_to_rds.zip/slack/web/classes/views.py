from slack_sdk.models.views import View  # noqa
from slack_sdk.models.views import ViewState  # noqa
from slack_sdk.models.views import ViewStateValue  # noqa

from slack import deprecation

deprecation.show_message(__name__, "slack_sdk.models.views")
